/* This program reads an integer from the file.
* In the file it is stored in 2 dimensional array. 
* Our task here is to find out 4 consecutive number and return a co-ordinates where it is found.
*
*
* Written by Saugat Gyawali for CS2336.001, assignment 2, starting September 18, 2021.
NetID: SXG200088
*/
package CS2336Asg2_SXG200088;
import java.util.*;
import java.io.*;


// main class.
// In this class. We ask for the files and display the matrix and sequence of the co-ordinates.
public class CS2336Asg2_SXG200088 
{
	// file not found exception is thrown in the main method.
	public static void main(String[] args) throws FileNotFoundException 
	{
		CS2336Asg2_SXG200088 cs = new CS2336Asg2_SXG200088();			// instantiation of own class's object to access the function.
		Scanner input = new Scanner(System.in);	
		String filename;
		
		// iterates till user enters asterisk(*).
		do
		{
		System.out.print("Enter a filename: ");
		filename = input.nextLine();
		
		// if entered "*". breaks the loop
		if(filename.equals("*"))
		{
		System.out.println("Thank You!");	
		break;
		}
		
		// creating a file object. 
		File file = new File (filename);
		
		// Checking whether an input file exist or not.
		if(!file.exists())
		{
			System.out.println("ERROR: File not found.\n");
		}
		else
		{
			Scanner inputFile = new Scanner(file);
			int row = inputFile.nextInt();								// takes first number in a file which is a row.
			int column = inputFile.nextInt();							// takes second number in a file which is a column.
			int[][] matrix = new int[row][column];				
			
			for(int i = 0; i < row; i++)
			{
				for(int j = 0; j < column; j++)
				{
					matrix[i][j] = inputFile.nextInt();					// loading an integer into 2-dimensional array.
				}
			}
			System.out.println("Given Matrix in the file is: ");
			cs.displayMatrix(matrix, row, column);						// displays a matrix in a file.
			System.out.println();
			cs.displaySequence(matrix, row, column);					// displays a sequence and co-ordinates 
			inputFile.close();															// closing of file.
		}
		}while(!filename.equals("*"));
		
		input.close();
}
	
	// this function here displays a sequence of 4 consecutive numbers.
	// also displays a co-ordinates where it is.
	void displaySequence(int[][] matrix, int row, int column)
	{
		SearchConsecutive obj2 = new SearchConsecutive();
		
		// checking sequence is found or not.
		if(obj2.searchForSequence(matrix, row, column) )
		{
			
			System.out.println("Sequence of " + obj2.getSequencedNumber() 
			+ " at " + obj2.getxCoordinate() + "," + obj2.getyCoordinate() + "\n");
		}
		else
		{
			System.out.println("Sequence not found.");
		}
	}
	
	// this function displays all the integer in the file in the form of 2-D array.
	 void displayMatrix(int[][] matrix, int row, int column)
	{
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < column; j++)
			{
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
	}
	  
}

// class here search for the consecutive numbers.
class SearchConsecutive
{
	private int xCoordinate;
	private int yCoordinate;
	private int sequencedNumber;
	
	
	// mutators to load a variable:
	void setNumbers(int x, int y, int temp)
	{
		this.xCoordinate = x;
		this.yCoordinate = y;
		this.sequencedNumber = temp;
		
	}
	
	int getxCoordinate()
	{
		return xCoordinate + 1;						// 1 is added because array starts with 0 origin.
	}
	
	int getyCoordinate()
	{
		return yCoordinate + 1;
	}
	
	int getSequencedNumber()
	{
		return sequencedNumber;
	}
	
	// actual function which checks for consecutive number.
	public boolean searchForSequence(int[][] matrix, int row, int column)
	{
		boolean found = true;
		boolean notFound = false;
		int tempNumber = matrix[0][0];											// initializing first element with 0,0
		
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < column; j++)
			{
				tempNumber = matrix[i][j];
				
				
				// this checks for the consecutive number in a row.
				// this is done to make sure that array does not get out of bound.
				if(j+3 < column)								
				{
					if(tempNumber == matrix[i][j+1]) 							// checks for next number in a row.
					{
						if(tempNumber == matrix[i][j+2])						// checks for the second next number in a row.
						{
							if(tempNumber == matrix[i][j+3])					// checks for the third next number. 
							{
								// calling of setter passes to pass an argument.
								setNumbers(i,j,tempNumber);
								return found;									// if found returns true and end of the function. 
																				// we only need to check for one consecutive number.	
							}
						}
					}
				}
				
			
				// this checks for the consecutive number in a column.
				if(i+3 < row)
				{
					if(tempNumber == matrix[i+1][j])
					{
						if(tempNumber == matrix[i+2][j]) 
						{
							if(tempNumber == matrix[i+3][j])
							{
								setNumbers(i,j,tempNumber);
								return found;
						}
					}
				}
				}
				
				
				
				// this checks for the consecutive number in a diagonal(Right).
				if(i+3 < row && j+3 < column)
				{
					if(tempNumber == matrix[i+1][j+1])
					{
						if(tempNumber == matrix[i+2][j+2])
						{
							if(tempNumber == matrix[i+3][j+3])
							{
								setNumbers(i,j,tempNumber);
								return found;
						     }
					}
				}
				}
				
				// this checks for the diagonal(Left)
				if(i+3 < row && j-3 >= 0)
				{
				if(tempNumber == matrix[i+1][j-1])
				{
					if(tempNumber == matrix[i+2][j-2])
					{
						if(tempNumber == matrix[i+3][j-3])
						{
							setNumbers(i,j,tempNumber);
							return found;
						}
					}
				}
				
					
			}
		}
		
			
}
		return notFound;		// if sequence not found returns false; 
}
}
	

	





