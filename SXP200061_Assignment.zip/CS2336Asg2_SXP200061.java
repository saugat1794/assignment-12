/* Program here reads an integer from the file and 
 * displays the matrix.
 * After displaying the matrix, it prints the consecutive number either in a row, 
 * or in column, or right or left diagonal.
*
* Written by Sandesh Pokharel for CS2336, assignment 2, starting September 17, 2021.
NetID: SXP200061
*/


import java.util.*;
import java.io.*;

public class CS2336Asg2_SXP200061 
	{
		//Main function
		public static void main(String[] args) throws Exception 
		{ 
			Scanner user = new Scanner( System.in ); // scanner class
			CS2336Asg2_SXP200061 ob1 = new CS2336Asg2_SXP200061();
			while (true)
			{ 
				// Execute the program until the user get * as a file name
				String inputFileName; // Declare input file
				System.out.print("Enter the file name: "); 
				inputFileName = user.nextLine().trim(); // Trim unnecessary spaces
				if (inputFileName.equals("*"))
				{ 
					// Exit if the user get "*" as a input file 
					System.out.println("Program over. Thank you.");
					break;
				}
				//Open file
				File file = new File(inputFileName); 
				if (file.exists())
				{ 
					// Run the program if the file if the file found
					Scanner sc = new Scanner(file); 
					// Read the first line of the file
					String row_col[] = sc.nextLine().split(" ");
					//Store the first value in n
					int n = Integer.parseInt(row_col[0]); 
					//Store the second value in m
					int m = Integer.parseInt(row_col[1]); 
					//create new array to store the matrix
					int arr[][] = new int[n][m]; 
					int i = 0;
					while (i<n)
					{ 
						// Read file, split it and store it 
						String row[] = sc.nextLine().split(" ");
						for(int j = 0;j<row.length;j++)
						arr[i][j] = Integer.parseInt(row[j]); 
						i++;
					}
					//make a object class for solution class
					Solution obj = new Solution(); 
					
					//Read m and n form file 
					int ans[] = obj.find_consecutive(arr,n,m); 
					ob1.displayMatrix(arr);
					//print the sequence if the answer exit in this sequence
					if (ans[0]!=-1) 
						//Print the output
						System.out.println("Sequence of "+arr[ans[0]][ans[1]]+" starts at "+(ans[0]+1)+","+(ans[1]+1)); 
					else 
						System.out.println("Sequence does not found.");
				}
				else
					System.out.println("Error. File does't exists"); 
			}
		}
		
		void displayMatrix(int[][] arr)
		{
			for(int i = 0; i < arr.length; i++)
				{
					for(int j = 0; j < arr[i].length; j++)
						{
							System.out.print(arr[i][j] + " ");
						}
					System.out.println();
				}
		}
		
	}



class Solution 
{ 
	public int[] find_consecutive(int a[][], int n, int m)
	{ 
		//create array of size 2
		int ans[] = new int[2]; 
		// Initialized both to -1
		ans[0] = -1; 
		ans[1] = -1;
		for(int i = 0;i<n;i++)
		{ 
			for(int j = 0;j<m;j++)
			{
				//Set the key as the current element
				int key = a[i][j];
				
				if (i+3<n)
				{
					//	//Check i upto number 3 when j is constant in the sequence of a single row 
					if (a[i+1][j]==key && a[i+2][j]==key && a[i+3][j]==key)
					{ 
						ans[0]= i; // index 0 shows row number i 
						ans[1] = j; // index 1 shows column number j 
						return ans; 
					}
				}
  
				if (j+3<m)
				{ 
					//Check j upto number 3 when i is constant in the sequence of a single row 
					if (a[i][j+1]==key && a[i][j+2]==key && a[i][j+3]==key)
					{
						ans[0]= i; // index 0 shows row number i 
						ans[1] = j; // index 1 shows column number j 
						return ans; 
					}
				}
  
				if (i+3<n && j+3<m)
				{
					//i and j are both increase at the same time when the sequence is diagonal
					if (a[i+1][j+1]==key && a[i+2][j+2]==key && a[i+3][j+3]==key)
					{ 
						ans[0]= i;
						ans[1] = j;
						return ans; 
					}
  
				}  
			}
		}
		return ans; 
  
	}
	
	public int[] find_consecutive11(int[][] arr, int n, int m) 
	{
	return null;
	}

	public int[] find_consecutive1(int[][] arr, int n, int m) 
	{
	return null;
	}
}

